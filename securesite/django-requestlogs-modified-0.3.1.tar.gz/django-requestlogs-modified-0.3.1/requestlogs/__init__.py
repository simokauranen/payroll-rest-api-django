from .base import get_requestlog_entry

name = 'requestlogs'
