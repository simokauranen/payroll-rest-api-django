try:
    from ipware import get_client_ip as _get_client_ip
except ModuleNotFoundError:
    _get_client_ip = lambda r: (None, None)
from .base import SETTINGS

def remove_secrets(data):
    data = data.copy()
    for master_key in SETTINGS['SECRETS']:
        key_chain = master_key.split(".")
        depth = len(key_chain)
        nested_data = [data]
        nested_keys = []
        for i in range(depth):
            key = key_chain[i]
            nested_keys.append(key)
            if key in nested_data[i]:
                if i+1 == depth:
                    # Found the lowest key, hide
                    nested_data[i][key] = '***'
                    # Upwards recursion
                    k = i
                    while k > 0:
                        nested_data[k-1][nested_keys[k-1]] = nested_data[k]
                        k -= 1
                    data = nested_data[0]
                else:
                    if isinstance(nested_data[i][key], list) and len(nested_data[i][key]) > 0:
                        nested_data.append(nested_data[i][key][0])
                    else:
                        nested_data.append(nested_data[i][key])
            else:   # Key not in the remaining data
                break
    return data

def get_client_ip(request):
    return _get_client_ip(request)[0]
